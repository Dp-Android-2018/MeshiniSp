package com.dp.meshinisp.view.ui.callback;

public interface OnDateTimeSelected {
    void onDateTimeReady(String date,String time);
}
