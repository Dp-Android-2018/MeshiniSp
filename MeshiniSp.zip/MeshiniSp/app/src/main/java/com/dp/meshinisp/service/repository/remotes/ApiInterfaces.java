package com.dp.meshinisp.service.repository.remotes;

public interface ApiInterfaces {

    //News
    //get all news
   /* @GET("/api/news/parliament")
    Observable<Response<NewsResponse>> getParliamentNews(@Query("page") int pageNumber);*/

}
