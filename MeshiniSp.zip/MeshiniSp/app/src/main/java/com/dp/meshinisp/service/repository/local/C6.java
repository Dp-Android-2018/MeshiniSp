package com.dp.meshinisp.service.repository.local;

public class C6 {
}
