package com.dp.meshinisp.service.model.global;

public class C2 {
}
