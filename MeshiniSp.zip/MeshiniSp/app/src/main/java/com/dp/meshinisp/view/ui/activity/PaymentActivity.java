package com.dp.meshinisp.view.ui.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.dp.meshinisp.R;


public class PaymentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
    }
}
